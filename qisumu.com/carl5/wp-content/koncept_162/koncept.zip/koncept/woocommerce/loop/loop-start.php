<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
<div id="portfolio-holder" class="clearfix"><ul id="portfolio" class="folio-grid light style-three cols-<?php echo get_option( 'krown_shop_columns', 'four' ); ?> layout-<?php echo get_option( 'krown_shop_style', 'masonry' ); ?> clearfix">